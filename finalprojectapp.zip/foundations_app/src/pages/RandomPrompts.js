{/*import { render } from "@testing-library/react";
import React from 'react';
import ReactDOM from 'react-dom';
class RandomPrompts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            min: 1,
            max: 3,
            string: ''
        }
    }

    componentDidMount() {
        this.setState({
            string: this.generateNumber(this.state.min, this.state.max)})
    }
    generateNumber = (min, max) => {
        var quote = ["ine", "two", "three"];
        var rand = Math.floor(Math.random() * max) + min;
        return quote[rand];
    }
}

render(

        <p>{this.state.string}</p>

);

ReactDOM.render(<RandomPrompts />, document.getElementById("where"));*/}