/// <reference types="react-scripts" />
 // Your web app's Firebase configuration
 export function GetProcessEnv () {

 let firebaseConfig = {
    apiKey: "AIzaSyCNJfzZGEH_MHJ6JZQfYHi7Iio9lwZaV18",
    authDomain: "gimm300writersblock.firebaseapp.com",
    databaseURL: "https://gimm300writersblock.firebaseio.com",
    projectId: "gimm300writersblock",
    storageBucket: "gimm300writersblock.appspot.com",
    messagingSenderId: "872027736389",
    appId: "1:872027736389:web:5b910bc44c56d7a020162c",
    measurementId: "G-FPRBG2VTD3"
  }; 
  return firebaseConfig
}
