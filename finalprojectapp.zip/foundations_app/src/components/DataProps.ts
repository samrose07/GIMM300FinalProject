export default interface DataProps {
    prompt?: string;
    title?: string;
    content?: string;
    date?: string;
    location?: string;
    clear?: any;
}